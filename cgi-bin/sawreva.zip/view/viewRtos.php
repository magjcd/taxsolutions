<?php
$vRtos = $RepCntObj->viewRtos();
echo "<pre>";
print_r($vRtos);
echo "</pre>";
?>
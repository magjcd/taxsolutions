<?php
if(isset($_GET['eid'])){
	//echo $_GET['eid'];
	?>
	<div class="row">
		<h1 class="heading-big">Update Representative</h1>
	</div>
	<?php
}
?>
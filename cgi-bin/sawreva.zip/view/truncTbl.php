<?php
$ContObj->truncTbl();

?>
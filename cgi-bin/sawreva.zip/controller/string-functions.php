<?php


echo addslashes("Muhammad Ali");
?>